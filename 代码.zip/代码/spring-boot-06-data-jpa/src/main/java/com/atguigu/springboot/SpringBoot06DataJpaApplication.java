package com.atguigu.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot06DataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot06DataJpaApplication.class, args);
	}
}
